# GAMEHUB Connected Prototype

## Run
1. Install Node.js 20+.
2. Open this folder in Terminal/Command Prompt.
3. Run `npm install`
4. Run `npm start`
5. Open http://localhost:3000

This version serves the frontend and backend from one Express app. PostgreSQL is intentionally not required for this demo.

## Included
Home, All Games, Game Details, Login, Sign Up, Tournaments, Wallet, Profile, Admin Dashboard and responsive mobile layout.

## Important
This is a prototype/demo. Real-money deposits, withdrawals, wagering and production KYC/payment integrations are disabled. Obtain applicable legal/compliance and provider approvals before enabling any real-money functionality.
