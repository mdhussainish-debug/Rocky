const express = require("express");
const helmet = require("helmet");
const path = require("path");
const app = express();
const PORT = process.env.PORT || 3000;

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json());

const games = [
 {id:1,name:"Sports Arena",category:"Sports",icon:"⚽"},
 {id:2,name:"Card Masters",category:"Cards",icon:"🃏"},
 {id:3,name:"Neon Slots",category:"Slots",icon:"🎰"},
 {id:4,name:"Arcade Rush",category:"Arcade",icon:"🕹️"},
 {id:5,name:"Skill Challenge",category:"Skill Games",icon:"🎯"},
 {id:6,name:"Crash Zone",category:"Crash Games",icon:"🚀"},
 {id:7,name:"Esports Battle",category:"Esports",icon:"🏆"},
 {id:8,name:"Virtual Sports",category:"Virtual Sports",icon:"🏇"},
 {id:9,name:"Racing Pro",category:"Racing",icon:"🏎️"},
 {id:10,name:"Lucky Draw",category:"Lottery",icon:"🎟️"},
 {id:11,name:"Table Masters",category:"Casino",icon:"♠️"},
 {id:12,name:"Fishing Quest",category:"Arcade",icon:"🎣"}
];
const tournaments = [
 {name:"Weekend Champions",prize:"Demo Prize Pool",players:"1,248"},
 {name:"Esports Showdown",prize:"Demo Prize Pool",players:"864"},
 {name:"Racing Masters",prize:"Demo Prize Pool",players:"512"}
];

app.get("/api/health",(req,res)=>res.json({ok:true,mode:"demo"}));
app.get("/api/games",(req,res)=>res.json(games));
app.get("/api/games/:id",(req,res)=>{
 const g=games.find(x=>x.id===Number(req.params.id));
 if(!g) return res.status(404).json({error:"Game not found"});
 res.json({...g,description:"GAMEHUB demo game page. Real-money play is disabled.",modes:["Practice","Tournament","Demo"]});
});
app.get("/api/tournaments",(req,res)=>res.json(tournaments));
app.get("/api/profile",(req,res)=>res.json({name:"Demo Player",email:"demo@example.com",kyc:"Not submitted",status:"Demo account"}));
app.get("/api/wallet",(req,res)=>res.json({balance:0,currency:"INR",transactions:[],realMoneyEnabled:false}));
app.get("/api/admin/summary",(req,res)=>res.json({users:12840,games:12,tournaments:3,pendingKyc:47,withdrawals:0,mode:"Demo"}));
app.post("/api/auth/register",(req,res)=>res.json({ok:true,message:"Demo account created. OTP is simulated.",user:{name:req.body.name||"Demo Player"}}));
app.post("/api/auth/login",(req,res)=>res.json({ok:true,message:"Demo login successful"}));
app.post("/api/deposit",(req,res)=>res.status(403).json({error:"Real-money deposits are disabled in this prototype."}));
app.post("/api/withdrawal",(req,res)=>res.status(403).json({error:"Real-money withdrawals are disabled in this prototype."}));

app.use(express.static(path.join(__dirname,"public")));
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`GAMEHUB running at http://localhost:${PORT}`));
